/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CH1_attn_Pin GPIO_PIN_2
#define CH1_attn_GPIO_Port GPIOE
#define CH1_amp_5_Pin GPIO_PIN_0
#define CH1_amp_5_GPIO_Port GPIOC
#define CH1_amp_2_5_Pin GPIO_PIN_1
#define CH1_amp_2_5_GPIO_Port GPIOC
#define CH0_attn_Pin GPIO_PIN_2
#define CH0_attn_GPIO_Port GPIOC
#define CH0_ACDC_Pin GPIO_PIN_3
#define CH0_ACDC_GPIO_Port GPIOC
#define CH1_ACDC_Pin GPIO_PIN_4
#define CH1_ACDC_GPIO_Port GPIOC
#define CH1_amp_1_Pin GPIO_PIN_5
#define CH1_amp_1_GPIO_Port GPIOC
#define CH1_amp_10_Pin GPIO_PIN_0
#define CH1_amp_10_GPIO_Port GPIOB
#define CH0_amp_1_Pin GPIO_PIN_1
#define CH0_amp_1_GPIO_Port GPIOB
#define CH0_amp_10_Pin GPIO_PIN_2
#define CH0_amp_10_GPIO_Port GPIOB
#define CH0_amp_5_Pin GPIO_PIN_12
#define CH0_amp_5_GPIO_Port GPIOE
#define CH0_amp_2_5_Pin GPIO_PIN_13
#define CH0_amp_2_5_GPIO_Port GPIOE
#define GAIN_C1_Pin GPIO_PIN_6
#define GAIN_C1_GPIO_Port GPIOC
#define GAIN_C0_Pin GPIO_PIN_7
#define GAIN_C0_GPIO_Port GPIOC
#define UCPD_FLT_Pin GPIO_PIN_9
#define UCPD_FLT_GPIO_Port GPIOC
#define UCPD_DBn_Pin GPIO_PIN_9
#define UCPD_DBn_GPIO_Port GPIOA

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
