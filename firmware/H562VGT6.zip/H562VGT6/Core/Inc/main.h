/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define datalength 4
#define PACK __attribute__((packed))
typedef struct PACK {
    uint8_t packet_type;
    //uint16_t bufferpos;
    //uint8_t oscch1[4];
    //uint8_t oscch2[4];
    //uint8_t logic[4];
   // uint16_t oscch1[datalength];
   // uint16_t oscch2[datalength];
   // uint16_t logic[datalength];

    uint8_t datastring[63];
} DATA_Packet;
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void ADCstop();
void ADCstart();
void sendData(int offset);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define CH0_ATTEN_Pin GPIO_PIN_2
#define CH0_ATTEN_GPIO_Port GPIOC
#define CH0_ACDC_Pin GPIO_PIN_3
#define CH0_ACDC_GPIO_Port GPIOC
#define GAIN_C0_Pin GPIO_PIN_3
#define GAIN_C0_GPIO_Port GPIOA
#define GAIN_C1_Pin GPIO_PIN_6
#define GAIN_C1_GPIO_Port GPIOA
#define CH1_ACDC_Pin GPIO_PIN_4
#define CH1_ACDC_GPIO_Port GPIOC
#define CH1_ATTEN_Pin GPIO_PIN_5
#define CH1_ATTEN_GPIO_Port GPIOC
#define CH1_AMP_1_10_Pin GPIO_PIN_0
#define CH1_AMP_1_10_GPIO_Port GPIOB
#define CH1_AMP_1_5_Pin GPIO_PIN_1
#define CH1_AMP_1_5_GPIO_Port GPIOB
#define CH1_AMP_1_2_5_Pin GPIO_PIN_2
#define CH1_AMP_1_2_5_GPIO_Port GPIOB
#define CH1_AMP_1_1_Pin GPIO_PIN_10
#define CH1_AMP_1_1_GPIO_Port GPIOB
#define CH0_AMP_1_10_Pin GPIO_PIN_12
#define CH0_AMP_1_10_GPIO_Port GPIOB
#define CH0_AMP_1_1_Pin GPIO_PIN_15
#define CH0_AMP_1_1_GPIO_Port GPIOB
#define LOGIC_IN8_Pin GPIO_PIN_8
#define LOGIC_IN8_GPIO_Port GPIOD
#define LOGIC_IN9_Pin GPIO_PIN_9
#define LOGIC_IN9_GPIO_Port GPIOD
#define LOGIC_IN10_Pin GPIO_PIN_10
#define LOGIC_IN10_GPIO_Port GPIOD
#define LOGIC_IN11_Pin GPIO_PIN_11
#define LOGIC_IN11_GPIO_Port GPIOD
#define LOGIC_IN12_Pin GPIO_PIN_12
#define LOGIC_IN12_GPIO_Port GPIOD
#define LOGIC_IN13_Pin GPIO_PIN_13
#define LOGIC_IN13_GPIO_Port GPIOD
#define LOGIC_IN14_Pin GPIO_PIN_14
#define LOGIC_IN14_GPIO_Port GPIOD
#define LOGIC_IN15_Pin GPIO_PIN_15
#define LOGIC_IN15_GPIO_Port GPIOD
#define CH0_AMP_1_2_5_Pin GPIO_PIN_6
#define CH0_AMP_1_2_5_GPIO_Port GPIOC
#define CH0_AMP_1_5_Pin GPIO_PIN_8
#define CH0_AMP_1_5_GPIO_Port GPIOC
#define UCPD_FLT_Pin GPIO_PIN_9
#define UCPD_FLT_GPIO_Port GPIOC
#define UCPD_DBn_Pin GPIO_PIN_9
#define UCPD_DBn_GPIO_Port GPIOA
#define LOGIC_IN0_Pin GPIO_PIN_0
#define LOGIC_IN0_GPIO_Port GPIOD
#define LOGIC_IN1_Pin GPIO_PIN_1
#define LOGIC_IN1_GPIO_Port GPIOD
#define LOGIC_IN2_Pin GPIO_PIN_2
#define LOGIC_IN2_GPIO_Port GPIOD
#define LOGIC_IN3_Pin GPIO_PIN_3
#define LOGIC_IN3_GPIO_Port GPIOD
#define LOGIC_IN4_Pin GPIO_PIN_4
#define LOGIC_IN4_GPIO_Port GPIOD
#define LOGIC_IN5_Pin GPIO_PIN_5
#define LOGIC_IN5_GPIO_Port GPIOD
#define LOGIC_IN6_Pin GPIO_PIN_6
#define LOGIC_IN6_GPIO_Port GPIOD
#define LOGIC_IN7_Pin GPIO_PIN_7
#define LOGIC_IN7_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
